import React from 'react'
import{BrowserRouter,Routes,Route} from "react-router-dom";
import Careers from './Component/CAREERS/Careers';
import Contactus from './Component/Contactus/Contactus';
import Header from './Component/Header';
import HomeImg from './Component/Homeimg';
import Homepage from './Component/Homepage';
import Service from './Component/Services/Service';
import Footer from './Component/Footer';
import Login from './Component/Login';
import About from './Component/About';
import Signup from './Component/Signup';
import ForgetPassword from './Component/ForgetPassword/Forgetpassword';
import Fresher from './Component/ApplicationForm/Fresher';
import Experience from './Component/ApplicationForm/Experience';
import Review from './Component/Review';
import ApplicationDevelopment from './Component/Services/ApplicationDevelopment';
import DigitalService from './Component/Services/DigitalService';
import StrategyConsulting from './Component/Services/StrategyConsulting';
import DevOps from './Component/Services/DevOps';
import SoaWebservice from './Component/Services/SoaWebservice';
import DataAnalyticsAi from './Component/Services/DataAnalyticsAi';




const App = () => {
  return (
    <div>
     <BrowserRouter>
        <Header/>
        <Routes>
         
          <Route path='/' exact element={<Homepage/>}></Route>
          <Route path='/Header' exact element={<Header/>}></Route>
          <Route path='/Contactus' exact element={<Contactus/>}></Route>
          <Route path='/Careers' exact element={<Careers/>}></Route>
          <Route path='/Homeimg' exact element={<HomeImg/>}></Route>
          <Route path='/Service' exact element={<Service/>}></Route>
          <Route path='/Footer' exact element={<Footer/>}></Route>
          <Route path='/About' exact element={<About/>}></Route>
          <Route path='/Login' exact element={<Login/>}></Route>
          <Route path='/Signup' exact element={<Signup/>}></Route>
          <Route path='/Forgetpassword' exact element={<ForgetPassword/>}></Route>
          <Route path='/Fresher' exact element={<Fresher/>}></Route>
          <Route path='/Experience' exact element={<Experience/>}></Route>
          <Route path='/Review' exact element={<Review/>}></Route>
          <Route path='/ApplicationDevelopment' exact element={<ApplicationDevelopment/>}></Route>
          <Route path='/DigitalService' exact element={<DigitalService/>}></Route>
          <Route path='/StrategyConsulting' exact element={<StrategyConsulting/>}></Route>
          <Route path='/DevOps' exact element={<DevOps/>}></Route>
          <Route path='/SoaWebservice' exact element={<SoaWebservice/>}></Route>
          <Route path='/DataAnalyticsAi' exact element={<DataAnalyticsAi/>}></Route>
       </Routes>
        <Footer/>
      </BrowserRouter>
      
    </div>
  )
}

export default App




