import React from 'react'
import Footer from '../Footer'
import Header from '../Header'
import { Link } from 'react-router-dom'
import './ForgetpasswordStyle.css';
const Forgetpassword = () => {
  return (
    <div>
      <Header/>
     
  <div className="auto-container" style={{marginTop:"100px"}}>
        {/*Subscribe Form*/}
        <div className="envelope-image " />
        <div className="contact-form ">
          <div className="form-inner">
            <div className="upper-box">
              <div className="sec-title text-center">
                <br />
                <h2>Forgot Password</h2>
                <div className="text">
                  Please enter your email address to search for your account..
                </div>
              </div>
            </div>
            <form
              method="post"
              action="forgot_password_submit"
              id="contact-form"
              noValidate="novalidate"
            >
              <div className="row clearfix">
                <div className="col-lg-2 col-md-4 col-sm-4" ></div>
                <div
                  className="col-lg-8 col-md-8 col-sm-8 form-group"
                  id="contact-form"
                >
                  <input
                    type="email"
                    autofocus=""
                    name="user"
                    defaultValue=""
                    placeholder="Enter Email ID"
                    tabIndex={1}
                    required=""
                  />
                  <br />
                  <div className="btn-box">
                  <Link to="/Login ">
                    <button
                   
                      className="theme-btn btn btn-style-one mb-3"
                      type="submit"
                      name="submit"
                      style={{ width: "100%" }}
                    >
                      <span className="btn-title">Submit</span>
                     
                    </button>
                    </Link>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    
      <Footer/>
    </div>
  )
}

export default Forgetpassword

