import React from "react";
import "./ServiceStyle.css";
import { Link } from "react-router-dom";
const Service = () => {
  return (
    <div className='frform' style={{ backgroundColor:'white', border: '7px solid white',margin:"40px",marginTop:"120px",position:'auto'}}>

    <div>
      <section
        className="categories section-padding-large grid grid-cols-3 md:grid-cols-1"
        style={{ marginTop:"-40px"}}
      >
        <div className="container">
          <div className="section-title section-title-center" style={{marginLeft:"500px"}}>
            <h1 style={{color:"black"}}>SERVICES</h1>
            
          </div>
          <div className="categories-content">
            <div className="categories group-1"></div>
            <div className="categories-group-2">
              <div className="row">
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                  <article className="item cat-3">
                    <figure>
                      {" "}
                      <Link to ="SoaWebService">
                        <img className="img123"
                          src="https://ms-cloud.com/images/categories-4.jpg"
                          alt=""
                        />
                      </Link>
                      <div className="info">
                        <h3 className="title">
                          {" "}
                          <a href="SoaWebService" >
                           <h2  style={{color:"black"}}> SOA and WebServices</h2>
                          </a>{" "}
                        </h3>
                        <span className="total-course">Services</span>{" "}
                      </div>
                    </figure>
                  </article>{" "}
                  <article className="item cat-3">
                    <figure>
                      {" "}
                      <a href="StrategyConsulting">
                        <img className="img123"
                          src="https://ms-cloud.com/images/categories-2.jpg"
                          alt=""
                        />
                      </a>
                      <div className="info">
                        <h3 className="title">
                          {" "}
                          <a href="StrategyConsulting">
                          <h2  style={{color:"black"}}>  Strategy&consulting</h2>
                          </a>{" "}
                        </h3>
                        <span className="total-course">Services</span>{" "}
                      </div>
                    </figure>
                  </article>
                </div>
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                  <article className="item cat-5">
                    <figure>
                      {" "}
                      <Link to="DevOps">
                        <img className="img123"
                          src="https://ms-cloud.com/images/categories-3.jpg"
                          alt=""
                        />
                      </Link>
                      <div className="info">
                        <h3 className="title">
                          {" "}
                          <Link to="DevOps" style={{color:"black"}}>DevOps</Link>{" "}
                        </h3>
                        <span className="total-course">Services</span>{" "}
                      </div>
                    </figure>
                  </article>
                  <article className="item cat-6">
                    <figure>
                      {" "}
                      <Link to="DigitalService">
                        <img className="img123"
                          src="https://ms-cloud.com/images/categories-5.jpg"
                          alt=""
                        />
                      </Link>
                      <div className="info">
                        <h3 className="title">
                          {" "}
                          <a href="DigitalService" style={{color:"black"}}>
                            Digital Services
                          </a>{" "}
                        </h3>
                        <span className="total-course">Services</span>{" "}
                      </div>
                    </figure>
                  </article>
                </div>{" "}
                <div className="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                  <article className="item cat-5">
                    <figure>
                      {" "}
                      <Link to="DataAnalyticsAi">
                        <img className="img123"
                          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDftuFUUbSKIMKilkbok1gdhmJI399o_j9Qw&usqp=CAU"
                          alt=""
                        />
                      </Link>
                      <div className="info">
                        <h3 className="title">
                          {" "}
                          <Link to="DataAnalyticsAi" style={{color:"black"}}>
                            Data Analytics and AI
                          </Link>{" "}
                        </h3>
                        <span className="total-course">Services</span>{" "}
                      </div>
                    </figure>
                  </article>{" "}
                  <article className="item cat-6">
                    <figure>
                      {" "}
                      <Link to="ApplicationDevelopment">
                        <img className="img123"
                          src="https://ms-cloud.com/images/categories-2.jpg"
                          alt=""
                        />
                      </Link>
                      <div className="info">
                        <h3 className="title">
                          {" "}
                          <Link to=" ApplicationDevelopment" style={{color:"black"}}>
                            Application Development
                          </Link>{" "}
                        </h3>
                        <span className="total-course">Services</span>{" "}
                      </div>
                    </figure>
                  </article>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    </div>
  );
};

export default Service;
