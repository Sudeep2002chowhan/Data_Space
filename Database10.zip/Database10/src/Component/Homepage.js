import React from 'react'
import HomeImg from './Homeimg'
import Service from './Services/Service'
import Careers from './CAREERS/Careers'
import Values from './Values'
import Review from './Review'


const Homepage = () => {
  return (
    <div>
    <HomeImg/>
   <Service/>
   <Values/>
   <Review/>
  
   
    </div>
  )
}

export default Homepage
