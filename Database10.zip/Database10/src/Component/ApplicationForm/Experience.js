// import React from 'react'
// import "./Exp.css"

// const Experience = () => {
//   return (
//     <div className='frform' style={{ backgroundColor:'lightpink', border: '7px solid black',margin:"40px",marginTop:"100px",position:'auto'}}>
//     <div style={{marginLeft:"-50px" , marginTop:"-70px"}}>
//       <div className="banner-forms" style={{marginTop:"100px" , width:"300px"}}>
//     <form method="post" className="banner-email" id="banner-form" noValidate="">
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName">
//     <div className="field-element" style={{marginLeft:"70px" , width:"300px"}} >
//       <input
//         id="bn-firstname"
//         type="text"
//         name="Rmlyc3QgbmFtZQ=="
//         data-label-inside="First name"
//         placeholder="Full Name *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         data-intl-tel-input-id={1}
//         defaultValue=""                
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName banner-call-input"
//    style={{marginLeft:"480px" , width:"200px"}}>
//     <div className="field-element" style={{marginTop:"-40px"}}>
//       <input
//         id="bn-Contact"
//         type="text"
//         name="UGhvbmUgbm8u"
//         data-label-inside="Contact no."
//         placeholder="Contact No. *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         autoComplete="off"
//         data-intl-tel-input-id={1}
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//       <input type="hidden" id="hidden-country" />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName" 
//    style={{marginLeft:"900px" , width:"300px" }}>
//     <div className="field-element "  style={{marginTop:"-55px"}}>
//       <input
//         id="bn-email"
//         type="email"
//         name="RW1haWw="
//         data-label-inside="Email"
//         placeholder="Email"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input required  "
//         pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"
//         defaultValue=""
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName home-last-name-field">
//     <div className="field-element ">
//       <input
//         id="bn-lastname"
//         type="hidden"
//         name="TGFzdCBuYW1l"
//         data-label-inside="Last name"
//         placeholder="Last Name"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue="Field not available"
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//   style={{marginLeft:"70px" , width:"300px" }}>
//     <div className="field-element">
//       <select
//         name="sb-coursename"
//         id="sb-coursename"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input required bn-coursename valid"
//         aria-invalid="false"
//       >
//         <option value="all" className="course_list active" data-slug="">
//           Education
//         </option>
//         <option value="12th">12th</option>
//         <option value="B.A. (Arts)		">B.A. (Arts) </option>
//         <option value="B.Com (Commerce)">B.Com (Commerce)</option>
//         <option value="B.Sc (Science)">B.Sc (Science)</option>
//         <option value="B.Arch (Architecture)	">B.Arch (Architecture) </option>
//         <option value="B.Ed (Education)	">B.Ed (Education) </option>
//         <option value="B.El.Ed (Elementary Education)	">
//           B.El.Ed (Elementary Education){" "}
//         </option>
//         <option value="B.Lib.Sc (Library Sciences)	">
//           B.Lib.Sc (Library Sciences){" "}
//         </option>
//         <option value="B.P.Ed. (Physical Education)">
//           B.P.Ed. (Physical Education)
//         </option>
//         <option value="B.Plan (Planning)	">B.Plan (Planning) </option>
//         <option value="	Bachelor of Fashion Technology		">
//           {" "}
//           Bachelor of Fashion Technology{" "}
//         </option>
//         <option value="	BBA/BBM/BBS	"> BBA/BBM/BBS </option>
//         <option value="BCA (Computer Application)		">
//           BCA (Computer Application){" "}
//         </option>
//         <option value="BE B.Tech (Engineering)">BE B.Tech (Engineering)</option>
//         <option value="BFA (Fine Arts)">BFA (Fine Arts)</option>
//         <option value="BHM (Hotel Management)	">BHM (Hotel Management) </option>
//         <option value="BL/LLB/BGL (Law)">BL/LLB/BGL (Law)</option>
//         <option value="BSW (Social Work)">BSW (Social Work)</option>
//         <option value="	B.Pharm (Pharmacy)		"> B.Pharm (Pharmacy) </option>
//         <option value="	B.V.Sc. (Veterinary Science)">
//           {" "}
//           B.V.Sc. (Veterinary Science)
//         </option>
//         <option value="BDS (Dental Surgery)	">BDS (Dental Surgery) </option>
//         <option value="BHMS (Homeopathy)">BHMS (Homeopathy)</option>
//         <option value="CA (Chartered Accountant)	">
//           CA (Chartered Accountant){" "}
//         </option>
//         <option value="CFA (Chartered Financial Analyst)">
//           CFA (Chartered Financial Analyst)
//         </option>
//         <option value="CS (Company Secretary)">CS (Company Secretary)</option>
//         <option value="ICWA">ICWA</option>
//         <option value="Integrated PG">Integrated PG</option>
//         <option value="Engineering">Engineering</option>
//         <option value="Fashion/ Design	">Fashion/ Design </option>
//         <option value="Languages	">Languages </option>
//         <option value="Pilot Licenses	">Pilot Licenses </option>
//         <option value="M.Arch. (Architecture)	">M.Arch. (Architecture) </option>
//         <option value="M.Ed. (Education)">M.Ed. (Education)</option>
//         <option value="M.Lib.Sc. (Library Sciences)">
//           M.Lib.Sc. (Library Sciences)
//         </option>
//         <option value="M.Plan. (Planning)">M.Plan. (Planning)</option>
//         <option value="Master of Fashion Technology">
//           Master of Fashion Technology
//         </option>
//         <option value="Master of Health Administration	">
//           Master of Health Administration{" "}
//         </option>
//         <option value="Master of Hospital Administration">
//           Master of Hospital Administration
//         </option>
//         <option value="MBA/PGDM">MBA/PGDM</option>
//         <option value="MCA PGDCA part time	">MCA PGDCA part time </option>
//         <option value="MCA/PGDCA">MCA/PGDCA</option>
//         <option value="ME/M.Tech/MS (Engg/Sciences)">
//           ME/M.Tech/MS (Engg/Sciences)
//         </option>
//         <option value="MFA (Fine Arts)	">MFA (Fine Arts) </option>
//         <option value="ML/LLM (Law)	">ML/LLM (Law) </option>
//         <option value="MSW (Social Work)	">MSW (Social Work) </option>
//         <option value="PG Diploma">PG Diploma</option>
//         <option value="M.Com. (Commerce)">M.Com. (Commerce)</option>
//         <option value="M.Sc. (Science)">M.Sc. (Science)</option>
//         <option value="MA (Arts)">MA (Arts)</option>
//         <option value="M.Pharm. (Pharmacy)	">M.Pharm. (Pharmacy) </option>
//         <option value="M.V.Sc. (Veterinary Science)">
//           M.V.Sc. (Veterinary Science)
//         </option>
//         <option value="MBBS">MBBS</option>
//         <option value="MD/ MS (Medicine)">MD/ MS (Medicine)</option>
//         <option value="MDS (Master of Dental Surgery)">
//           MDS (Master of Dental Surgery)
//         </option>
//         <option value="BPT (Physiotherapy">BPT (Physiotherapy)</option>
//         <option value="MPT (Physiotherapy)">MPT (Physiotherapy)</option>
//         <option value="M.Phil. (Philosophy)">M.Phil. (Philosophy)</option>
//         <option value="Ph.D. (Doctorate)	">Ph.D. (Doctorate) </option>
//         <option value="Other Doctorate">Other Doctorate</option>
//         <option value="Other Diploma">Other Diploma</option>
//         <option value="Agriculture">Agriculture</option>
//         <option value="10th">10th</option>{" "}
//       </select>
//       <div className="loader-overlay">
//         <div className="postloader select-loader" style={{ display: "none" }} />
//       </div>
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//   style={{marginLeft:"480px" , width:"300px" }}>
//     <div className="field-element" style={{marginTop:"-57px"}}>
//       <select
//         name="selectprograms"
//         id="bn-programname"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input required bn-programs"
//       >
//         <option value="">Occupation</option>
//         <option value="Science">Science</option>{" "}
//         <option value="Architecture & Design">Architecture &amp; Design</option>
//         <option value="Artists">Artists</option>
//         <option value=" Animators & Web Designers">
//           {" "}
//           Animators &amp; Web Designers
//         </option>
//         <option value="Banking">Banking</option>
//         <option value=" Insurance & Financial Services">
//           {" "}
//           Insurance &amp; Financial Services
//         </option>
//         <option value="Beauty">Beauty</option>
//         <option value=" Fashion & Jewellery Designers">
//           {" "}
//           Fashion &amp; Jewellery Designers
//         </option>
//         <option value="Business Owner / Entrepreneur">
//           Business Owner / Entrepreneur
//         </option>
//         <option value="Civil Services / Law Enforcement">
//           Civil Services / Law Enforcement
//         </option>
//         <option value="Construction">Construction</option>
//         <option value="Customer Service/ Call Centre/BPO">
//           Customer Service/ Call Centre/BPO
//         </option>
//         <option value="Defence">Defence</option>
//         <option value="Education/ Training">Education/ Training</option>
//         <option value="Electronics">Electronics</option>
//         <option value="Export/ Import">Export/ Import</option>
//         <option value="Finance and Accounts">Finance and Accounts</option>
//         <option value="Government Employee">Government Employee</option>
//         <option value="Health Care">Health Care</option>
//         <option value="Hotels/ Restaurants">Hotels/ Restaurants</option>
//         <option value="Human Resource">Human Resource</option>
//         <option value="IT">IT</option>
//         <option value="Legal">Legal</option>
//         <option value="Management / Corporate Professionals">
//           Management / Corporate Professionals
//         </option>
//         <option value="Manufacturing/ Engineering/ R&D">
//           Manufacturing/ Engineering/ R&amp;D
//         </option>
//         <option value="Marketing and Communications">
//           Marketing and Communications
//         </option>
//         <option value="Merchant Navy">Merchant Navy</option>
//         <option value="Non Working">Non Working</option>
//         <option value="Oil & Gas">Oil &amp; Gas</option>
//         <option value="Others">Others</option>
//         <option value="Pharmaceutical/ Biotechnology">
//           Pharmaceutical/ Biotechnology
//         </option>
//         <option value="Purchase/ Logistics/ Supply chain">
//           Purchase/ Logistics/ Supply chain
//         </option>
//         <option value="Real Estate">Real Estate</option>
//         <option value="Retail Chains">Retail Chains</option>
//         <option value="Sales/ Business Development">
//           Sales/ Business Development
//         </option>
//         <option value="Science">Science</option>
//         <option value="Telecom/ ISP">Telecom/ ISP</option>
//         <option value="Travel/ Airlines">Travel/ Airlines</option>{" "}
//       </select>
//       <div className="loader-overlay">
//         <div className="postloader select-loader" style={{ display: "none" }} />
//       </div>
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//    style={{marginLeft:"900px" , width:"300px" }} >
//     <div className="field-element" style={{marginTop:"-60px"}}>
//       <select
//         name=""
//         id="bn-10th passout year"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input required bn-programs"
//       >
//         <option value="">10th passout year</option>
//         <option>2000</option>
//         <option>2001</option>
//         <option>2002</option>
//         <option>2003</option>
//         <option>2004</option>
//         <option>2005</option>
//         <option>2006</option>
//         <option>2007</option>
//         <option>2008</option>
//         <option>2009</option>
//         <option>2010</option>
//         <option>2011</option>
//         <option>2012</option>
//         <option>2013</option>
//         <option>2014</option>
//         <option>2015</option>
//         <option>2016</option>
//         <option>2017</option>
//         <option>2018</option>
//         <option>2019</option>
//         <option>2020</option>
//       </select>
//       <div className="loader-overlay">
//         <div className="postloader select-loader" style={{ display: "none" }} />
//       </div>
//     </div>
//   </div>
//   <input type="text" placeholder="10th % percentge" style={{marginLeft:"70px" , width:"300px" , marginTop:"25px" }} />
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//    style={{marginLeft:"480px" , width:"300px" , marginTop:"-56px"}}>
//     <div className="field-element">
//       <select
//         name=""
//         id="bn-intermediate /diploma year of passout "
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input required bn-programs"
//       >
//         <option value="">intermediate /diploma year of passout </option>
//         <option>2000</option>
//         <option>2001</option>
//         <option>2002</option>
//         <option>2003</option>
//         <option>2004</option>
//         <option>2005</option>
//         <option>2006</option>
//         <option>2007</option>
//         <option>2008</option>
//         <option>2009</option>
//         <option>2010</option>
//         <option>2011</option>
//         <option>2012</option>
//         <option>2013</option>
//         <option>2014</option>
//         <option>2015</option>
//         <option>2016</option>
//         <option>2017</option>
//         <option>2018</option>
//         <option>2019</option>
//         <option>2020</option>
//       </select>
//       <div className="loader-overlay">
//         <div className="postloader select-loader" style={{ display: "none" }} />
//       </div>
//     </div>
//   </div>
//   <div style={{marginTop:"-40px"}}>
//   <input type="text" placeholder="intermediate /diploma year of passout %" 
//   style={{marginLeft:"900px" , width:"300px" }} />
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//   style={{marginLeft:"70px" , width:"300px", marginTop:"15px" }}>
//     <div className="field-element">
//       <select
//         name=""
//         id="bn- year of passout of graduate , pg , php"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input required bn-programs"
//       >
//         <option value=""> year of passout of graduate , pg , php</option>
//         <option>2000</option>
//         <option>2001</option>
//         <option>2002</option>
//         <option>2003</option>
//         <option>2004</option>
//         <option>2005</option>
//         <option>2006</option>
//         <option>2007</option>
//         <option>2008</option>
//         <option>2009</option>
//         <option>2010</option>
//         <option>2011</option>
//         <option>2012</option>
//         <option>2013</option>
//         <option>2014</option>
//         <option>2015</option>
//         <option>2016</option>
//         <option>2017</option>
//         <option>2018</option>
//         <option>2019</option>
//         <option>2020</option>
//       </select>
//       <div className="loader-overlay">
//         <div className="postloader select-loader" style={{ display: "none" }} />
//       </div>
//     </div>
//   </div>
//   <div style={{ marginTop:"-40px"}}>
//   <input type="text" placeholder=" year of passout of graduate , pg , php %" 
//     style={{marginLeft:"480px" , width:"300px"}}/>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//   style={{marginLeft:"900px" , width:"300px" , marginTop:"-55px"}}>
//     <div className="field-element">
//       <select
//         name=""
//         id="bn-Experience/Freshe"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input required bn-programs"
//       >
//         <option value="">Experience/Fresher</option>
//         <option>Fresher</option>
//         <option>Experience</option>
//       </select>
//       <div className="loader-overlay">
//         <div className="postloader select-loader" style={{ display: "none" }} />
//       </div>
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//   style={{marginLeft:"40px"}}>
//     <div className="field-element"  style={{width:"300px" ,  margin:"30px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="If Gap Explain *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//         />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"480px" ,width:"300px" }}>
//     <div className="field-element" style={{marginTop:"-70px"}} >
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="If Experience Explain *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"900px" ,width:"300px" }}>
//     <div className="field-element" style={{marginTop:"-70px"}} >
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="Standing Backlog *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"70px"}}>
//     <div className="field-element"  style={{width:"300px" }}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="1st company name *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"480px"}}>
//     <div className="field-element"  style={{width:"300px" , marginTop:"-40px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder=" CTC *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"900px"}}>
//     <div className="field-element"  style={{width:"300px" , marginTop:"-45px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="Duration *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"45px"}}>
//     <div className="field-element"  style={{width:"300px", margin:"25px" }}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="2st company name *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"480px"}}>
//     <div className="field-element"  style={{width:"300px" , marginTop:"-65px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder=" CTC *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"900px"}}>
//     <div className="field-element"  style={{width:"300px" , marginTop:"-70px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="Duration *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"70px"}}>
//     <div className="field-element"  style={{width:"300px" }}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="3st company name *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"480px"}}>
//     <div className="field-element"  style={{width:"300px" , marginTop:"-40px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder=" CTC *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName"
//    style={{marginLeft:"900px"}}>
//     <div className="field-element"  style={{width:"300px" , marginTop:"-45px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="Duration *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//   style={{marginLeft:"45px"}}>
//     <div className="field-element" style={{margin:"25px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="Permanant Address *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"1130px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select"
//   style={{marginLeft:"60px"}}>
//     <div className="field-element" style={{margin:"10px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="Current Address *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"1130px"}}
//       />
//     </div>
//   </div>
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName input-select" 
//    style={{marginLeft:"50px"}}>
//     <div className="field-element"  style={{margin:"20px"}}>
//       <input
//         id=""
//         type="text"
//         name=""
//         data-label-inside=""
//         placeholder="Parents contact number *"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  required  "
//         pattern="[A-Za-z]*"
//         defaultValue=""
//         style={{width:"300px"}}
//       />
//     </div>
//   </div>
//   {/* <div className="input-holder field-text wpcf7-form-control-wrap inputName home-city-field">
//     <div className="field-element ">
//       <input
//         id="bn-city"
//         type="hidden"
//         name="Q2l0eQ=="
//         data-label-inside="City"
//         placeholder="City"
//         className="wpcf7-form-control wpcf7-text wpcf7-validates-as-required shortnice form-input  "
//         defaultValue="Field not available"
//       />
//     </div>
//   </div> */}
//   <div className="input-holder field-text wpcf7-form-control-wrap inputName">
//     <div
//       id="llama-form-status"
//       className="banner-bv field-element llama-center"
//     />
//     <div className="field-element llama-center ">
//       <input type="submit" id="llama-bnbutton" className="llamasubmit" />
//       <div className="loader-overlay">
//         <div className="postloader submit-loader" style={{ display: "none" }} />
//       </div>
//     </div>
//   </div>
//   {/* <input type="hidden" id="hd-redirect" name="redirect" defaultValue="" />
//   <input type="hidden" id="hd-category" name="catname" defaultValue="" />
//   <input type="hidden" id="hd-folderName" name="folderName" defaultValue="" />
//   <input
//     type="hidden"
//     id="hd-course_title"
//     name="course_title"
//     defaultValue=""
//   />
//   <input type="hidden" id="hd-courseName" name="courseName" defaultValue="" />
//   <input
//     type="hidden"
//     id="hd-currenturl"
//     name="currenturl"
//     defaultValue="https://www.upgrad.com/blog/dbms-project-ideas-for-beginners"
//   />
//   <input type="hidden" id="hd-cn" name="cn" defaultValue="" /> */}
//   {/* <div className="llama-small">
//     By clicking 'Submit' you Agree to{" "}
//     <a
//       href="https://www.upgrad.com/terms?iref=Blog_Leadform_TermsNConditions"
//       title="UpGrads Terms & Conditions"
//     >
//       UpGrad's Terms &amp; Conditions
//     </a>
//   </div> */}
// </form>

// </div>
// </div>
// </div>

//   )
// }

// export default Experience


////  New experience page


import React, { useState } from 'react';
import "./ExperienceStyle.css"
const Experience = () => {
  const [Fullname, setFullname] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [email, setEmail] = useState('');
  const [education, setEducation] = useState('');
  const [occupation, setOccupation] = useState('');
  const [tenthPassoutYear, setTenthPassoutYear] = useState('');
  const [tenthPassPercentage, setTenthPassPercentage] = useState('');
  const [interDiplomaPassoutYear, setInterDiplomaPassoutYear] = useState('');
  const [interDiplomaPassPercentage, setInterDiplomaPassPercentage] = useState('');
  const [pgPhdGraduateYearOfPassout, setPgPhdGraduateYearOfPassout] = useState('');
  const [pgPhdGraduateYearOfPassPercentage, setPgPhdGraduateYearOfPassPercentage] = useState('');
  const [IfGapExplain, setIfGapExplain] = useState('');
  const [IfExperienceExplain, setIfExperienceExplain] = useState('');
  const [StandingBackLog, setStandingBackLog] = useState('');
  const [FirstCompanyName, setFirstCompanyName] = useState('');
  const [ThirdCompanyName, setThirdCompanyName] = useState('');
  const [CTC, setCTC] = useState('');
  const [Duration, setDuration] = useState('');
  const [lookingFor, setLookingFor] = useState('');

  const [SecondCompanyName, setSecondCompanyName] = useState('');
  const [permanentAddress, setPermanentAddress] = useState('');
  const [currentAddress, setCurrentAddress] = useState('');
  const [parentContactNumber, setParentContactNumber] = useState('');
  const [errors, setErrors] = useState({});

  const handleSubmit = (e) => {
    e.preventDefault();

    const validationErrors = {};

    if (!Fullname.trim()) {
      validationErrors.Fullname = 'Please enter a Fullname';
    }

    if (!contactNumber.trim()) {
      validationErrors.contactNumber = 'Please enter a contact number';
    }

    if (!email.trim()) {
      validationErrors.email = 'Please enter an email';
    } else if (!validateEmail(email)) {
      validationErrors.email = 'Please enter a valid email';
    }

    if (!education.trim()) {
      validationErrors.education = 'Please select an education option';
    }

    if (!occupation.trim()) {
      validationErrors.occupation = 'Please enter an occupation';
    }

    if (!tenthPassoutYear.trim()) {
      validationErrors.tenthPassoutYear = 'Please enter the year of passing the tenth';
    }

    if (!tenthPassPercentage.trim()) {
      validationErrors.tenthPassPercentage = 'Please enter the percentage in the tenth';
    }

    if (!interDiplomaPassoutYear.trim()) {
      validationErrors.interDiplomaPassoutYear = 'Please enter the year of passing the inter/diploma';
    }

    if (!interDiplomaPassPercentage.trim()) {
      validationErrors.interDiplomaPassPercentage = 'Please enter the percentage in the inter/diploma';
    }

    if (!pgPhdGraduateYearOfPassout.trim()) {
      validationErrors.pgPhdGraduateYearOfPassout = 'Please enter the year of passing PG/PhD';
    }

    if (!pgPhdGraduateYearOfPassPercentage.trim()) {
      validationErrors.pgPhdGraduateYearOfPassPercentage = 'Please enter the percentage in PG/PhD';
    }

    if (!lookingFor.trim()) {
      validationErrors.lookingFor = 'Please enter you are looking for';
    }

    if (!IfGapExplain.trim()) {
      validationErrors.IfGapExplain = 'Please enter  you are If Gap Explain';
    }
    if (!IfExperienceExplain.trim()) {
      validationErrors.IfExperienceExplain = 'Please enter  you are If Experience Explain';
    }
    if (!StandingBackLog.trim()) {
      validationErrors.StandingBackLog = 'Please enter  you are Standing Back Log';
    }
   if (!FirstCompanyName.trim()) {
      validationErrors.FirstCompanyName = 'Please enter  are First Company name';
    }
    if (!CTC.trim()) {
      validationErrors.CTC = 'Please enter the CTC';
    }
    if (!Duration.trim()) {
      validationErrors.Duration = 'Please enter  you are Duration';
    }
    if (!SecondCompanyName.trim()) {
      validationErrors.SecondCompanyName = 'Please enter  you are Second Company name';
    }
    if (!CTC.trim()) {
      validationErrors.CTC = 'Please enter the CTC';
    }
    if (!Duration.trim()) {
      validationErrors.Duration = 'Please enter the Duration';
    }
    if (!ThirdCompanyName.trim()) {
      validationErrors.ThirdCompanyName = 'Please enter the Third Company Name ';
    }
    if (!CTC.trim()) {
      validationErrors.CTC = 'Please enter  the CTC';
    }
    if (!Duration.trim()) {
      validationErrors.Duration = 'Please enter  the Duration';
    }
    
    if (!permanentAddress.trim()) {
      validationErrors.permanentAddress = 'Please enter the permanent address';
    }
    if (!currentAddress.trim()) {
      validationErrors.currentAddress = 'Please enter the current address';
    }

    if (!parentContactNumber.trim()) {
      validationErrors.parentContactNumber = 'Please enter a parent contact number';
    } else if (!validatePhoneNumber(parentContactNumber)) {
      validationErrors.parentContactNumber = 'Please enter a valid 10-digit contact number';
    }

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    // Continue with form submission if all validations pass
    // ...

    // Reset form after submission
    setFullname('');
    setContactNumber('');
    setEmail('');
    setEducation('');
    setOccupation('');
    setTenthPassoutYear('');
    setTenthPassPercentage('');
    setInterDiplomaPassoutYear('');
    setInterDiplomaPassPercentage('');
    setPgPhdGraduateYearOfPassout('');
    setPgPhdGraduateYearOfPassPercentage('');
    setLookingFor('');
    setIfGapExplain('');
    setIfExperienceExplain('');
    setStandingBackLog('');
    setFirstCompanyName('');
    setSecondCompanyName('');
    setThirdCompanyName('');
    setCTC('');
    setDuration('');
    setPermanentAddress('');
    setCurrentAddress('');
    setParentContactNumber('');
    setErrors({});
  };

  const validateEmail = (email) => {
    // Email validation logic
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const validatePhoneNumber = (phoneNumber) => {
    // Phone number validation logic
    return /^\d{10}$/.test(phoneNumber);
  };

  return (
    <>
    <div>
    <form className="form-container" onSubmit={handleSubmit} style={{marginTop: "10rem", background: "#e6e3e1", padding: "2rem"}}>
      {errors.Fullname && <span className="error-message">{errors.Fullname}</span>}
      <label>
        Full name:
        <input type="text" value={Fullname} onChange={(e) => setFullname(e.target.value)} />
      </label>
      {errors.contactNumber && <span className="error-message">{errors.contactNumber}</span>}
      <label>
        Contact Number:
        <input type="text" value={contactNumber} onChange={(e) => setContactNumber(e.target.value)} />
      </label>
      {errors.email && <span className="error-message">{errors.email}</span>}
      <label>
        Email:
        <input type="text" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      {errors.education && <span className="error-message">{errors.education}</span>}
      <label>
        Education:
        {/* <select value={education} onChange={(e) => setEducation(e.target.value)}>
          <option value="">Select</option>
          <option value="Option 1">10th</option>
          <option value="Option 2">Inter & Diploma</option>
          <option value="Option 3">Graduate</option>
          <option value="Option 3">Pg & PhD</option>
        </select> */}
        {/* <select value={occupation} onChange={(e) => setOccupation(e.target.value)}>
          <option value="">Select</option>
          <option value="Option 1">Business Owner / Entrepreneur</option>
          <option value="Option 2">Civil Services / Law Enforcement</option>
          <option value="Option 3">Construction</option>
          <option value="Option 4">Customer Service/ Call Centre/BPO</option>
          <option value="Option 5">Defence</option>
          <option value="Option 6">ertg</option>
          <option value="Option 7">gfg</option>
          <option value="Option 8">uygyug</option>
        </select> */}
        <select name="occupation">
  <option value="">Select Occupation</option>
  <optgroup label="10th">
    <option value="High School Diploma">High School Diploma</option>
    <option value="Vocational Training">Vocational Training</option>
    <option value="Apprenticeship">Apprenticeship</option>
    <option value="Entry-Level Jobs">Entry-Level Jobs</option>
  </optgroup>
  <optgroup label="12th">
    <option value="Higher Secondary Diploma">Higher Secondary Diploma</option>
    <option value="Diploma Courses">Diploma Courses</option>
    <option value="Junior College">Junior College</option>
    <option value="Government Jobs">Government Jobs</option>
  </optgroup>
  <optgroup label="Graduation">
    <option value="Bachelor's Degree">Bachelor's Degree</option>
    <option value="Internships">Internships</option>
    <option value="Entry-Level Jobs">Entry-Level Jobs</option>
    <option value="Higher Education">Higher Education</option>
  </optgroup>
  <optgroup label="Post-Graduation / PhD">
    <option value="Master's Degree">Master's Degree</option>
    <option value="Doctorate">Doctorate (PhD)</option>
    <option value="Research Positions">Research Positions</option>
    <option value="Academic Careers">Academic Careers</option>
  </optgroup>
</select>

        {/* <input type="text" value={occupation} onChange={(e) => setOccupation(e.target.value)} /> */}
      </label>
      {errors.occupation && <span className="error-message">{errors.occupation}</span>}
      <label>
        Occupation:
        {/* <select value={occupation} onChange={(e) => setOccupation(e.target.value)}>
          <option value="">Select</option>
          <option value="Option 1">Business Owner / Entrepreneur</option>
          <option value="Option 2">Civil Services / Law Enforcement</option>
          <option value="Option 3">Construction</option>
          <option value="Option 4">Customer Service/ Call Centre/BPO</option>
          <option value="Option 5">Defence</option>
          <option value="Option 6">ertg</option>
          <option value="Option 7">gfg</option>
          <option value="Option 8">uygyug</option>
        </select> */}
        <select name="occupation">
        <option value="">Select an occupation</option>
      <option value="teacher">Teacher</option>
      <option value="doctor">Doctor</option>
      <option value="engineer">Engineer</option>
      <option value="accountant">Accountant</option>
      <option value="designer">Designer</option>
      <option value="developer">Developer</option>
      <option value="nurse">Nurse</option>
      <option value="lawyer">Lawyer</option>
      <option value="chef">Chef</option>
      <option value="pilot">Pilot</option>
      <option value="writer">Writer</option>
      <option value="other">Other</option>
          
  {/* <option value="">Select Occupation</option>
  <optgroup label="10th">
    <option value="High School Diploma">High School Diploma</option>
    <option value="Vocational Training">Vocational Training</option>
    <option value="Apprenticeship">Apprenticeship</option>
    <option value="Entry-Level Jobs">Entry-Level Jobs</option>
  </optgroup>
  <optgroup label="12th">
    <option value="Higher Secondary Diploma">Higher Secondary Diploma</option>
    <option value="Diploma Courses">Diploma Courses</option>
    <option value="Junior College">Junior College</option>
    <option value="Government Jobs">Government Jobs</option>
  </optgroup>
  <optgroup label="Graduation">
    <option value="Bachelor's Degree">Bachelor's Degree</option>
    <option value="Internships">Internships</option>
    <option value="Entry-Level Jobs">Entry-Level Jobs</option>
    <option value="Higher Education">Higher Education</option>
  </optgroup>
  <optgroup label="Post-Graduation / PhD">
    <option value="Master's Degree">Master's Degree</option>
    <option value="Doctorate">Doctorate (PhD)</option>
    <option value="Research Positions">Research Positions</option>
    <option value="Academic Careers">Academic Careers</option>
  </optgroup> */}
</select>

        {/* <input type="text" value={occupation} onChange={(e) => setOccupation(e.target.value)} /> */}
      </label>
      {errors.tenthPassoutYear && <span className="error-message">{errors.tenthPassoutYear}</span>}
      <label>
        Tenth Passout Year:
        <select value={tenthPassoutYear} onChange={(e) => setTenthPassoutYear(e.target.value)}>
          <option value="">Select</option>
          <option value="Option 1">2000</option>
          <option value="Option 2">2001</option>
          <option value="Option 3">2003</option>
          <option value="Option 4">2004</option>
          <option value="Option 5">2005</option>
          <option value="Option 6">2006</option>
          <option value="Option 7">2007</option>
          <option value="Option 8">2008</option>
          <option value="Option 9">2009</option>
          <option value="Option 10">2010</option>
          <option value="Option 11">2011</option>
          <option value="Option 12">2012</option>
          <option value="Option 13">2013</option>
          <option value="Option 14">2014</option>
          <option value="Option 15">2015</option>
          <option value="Option 16">2016</option>
          <option value="Option 17">2017</option>
          <option value="Option 18">2018</option>
          <option value="Option 19">2019</option>
          <option value="Option 20">2020</option>
        </select>
        {/* <input type="text" value={tenthPassoutYear} onChange={(e) => setTenthPassoutYear(e.target.value)} /> */}
      </label>
      {errors.tenthPassPercentage && <span className="error-message">{errors.tenthPassPercentage}</span>}
      <label>
        Tenth Pass Percentage:
        <input type="text" value={tenthPassPercentage} onChange={(e) => setTenthPassPercentage(e.target.value)} />
      </label>
      {errors.interDiplomaPassoutYear && <span className="error-message">{errors.interDiplomaPassoutYear}</span>}
      <label>
        Inter/Diploma Passout Year:
        <select value={tenthPassoutYear} onChange={(e) => setInterDiplomaPassoutYear(e.target.value)}>
          <option value="">Select</option>
          <option value="Option 1">2000</option>
          <option value="Option 2">2001</option>
          <option value="Option 3">2003</option>
          <option value="Option 4">2004</option>
          <option value="Option 5">2005</option>
          <option value="Option 6">2006</option>
          <option value="Option 7">2007</option>
          <option value="Option 8">2008</option>
          <option value="Option 9">2009</option>
          <option value="Option 10">2010</option>
          <option value="Option 11">2011</option>
          <option value="Option 12">2012</option>
          <option value="Option 13">2013</option>
          <option value="Option 14">2014</option>
          <option value="Option 15">2015</option>
          <option value="Option 16">2016</option>
          <option value="Option 17">2017</option>
          <option value="Option 18">2018</option>
          <option value="Option 19">2019</option>
          <option value="Option 20">2020</option>
          <option value="Option 18">2021</option>
          <option value="Option 19">2022</option>
          <option value="Option 20">2023</option>
        </select>
        {/* <input type="text" value={interDiplomaPassoutYear} onChange={(e) => setInterDiplomaPassoutYear(e.target.value)} /> */}
      </label>
      {errors.interDiplomaPassPercentage && <span className="error-message">{errors.interDiplomaPassPercentage}</span>}
      <label>
        Inter/Diploma Pass Percentage:
        <input type="text" value={interDiplomaPassPercentage} onChange={(e) => setInterDiplomaPassPercentage(e.target.value)} />
      </label>
      {errors.pgPhdGraduateYearOfPassout && <span className="error-message">{errors.pgPhdGraduateYearOfPassout}</span>}
      <label>
         Graduate  PG/PhD Year of Passout:
         <select value={pgPhdGraduateYearOfPassout} onChange={(e) => setPgPhdGraduateYearOfPassout(e.target.value)}>
          <option value="">Select</option>
          <option value="Option 1">2000</option>
          <option value="Option 2">2001</option>
          <option value="Option 3">2003</option>
          <option value="Option 4">2004</option>
          <option value="Option 5">2005</option>
          <option value="Option 6">2006</option>
          <option value="Option 7">2007</option>
          <option value="Option 8">2008</option>
          <option value="Option 9">2009</option>
          <option value="Option 10">2010</option>
          <option value="Option 11">2011</option>
          <option value="Option 12">2012</option>
          <option value="Option 13">2013</option>
          <option value="Option 14">2014</option>
          <option value="Option 15">2015</option>
          <option value="Option 16">2016</option>
          <option value="Option 17">2017</option>
          <option value="Option 18">2018</option>
          <option value="Option 19">2019</option>
          <option value="Option 20">2020</option>
          <option value="Option 18">2021</option>
          <option value="Option 19">2022</option>
          <option value="Option 20">2023</option>
        </select>
         
        {/* <input type="text" value={pgPhdGraduateYearOfPassout} onChange={(e) => setPgPhdGraduateYearOfPassout(e.target.value)} /> */}
      </label>
      {errors.pgPhdGraduateYearOfPassPercentage && <span className="error-message">{errors.pgPhdGraduateYearOfPassPercentage}</span>}
      <label>
        PG/PhD Graduate Year of Pass Percentage:
        <input type="text" value={pgPhdGraduateYearOfPassPercentage} onChange={(e) => setPgPhdGraduateYearOfPassPercentage(e.target.value)} />
      </label>
      {errors.lookingFor && <span className="error-message">{errors.lookingFor}</span>}
      <label>
        Looking For:
        <select value={education} onChange={(e) => setEducation(e.target.value)}>
          <option value="">Select</option>
          <option value="Option 1">Fresher</option>
          <option value="Option 2">Experience</option>
        </select>
        {/* <input type="text" value={lookingFor} onChange={(e) => setLookingFor(e.target.value)} /> */}
      </label>
      {errors.IfGapExplain && <span className="error-message">{errors.IfGapExplain}</span>}
      <label>
      IF Gap Explain (in Year) IF not type N/A :
        <input type="text" value={IfGapExplain} onChange={(e) => setIfGapExplain(e.target.value)} />
      </label>
      {errors.IfExperienceExplain && <span className="error-message">{errors.IfExperienceExplain}</span>}
      <label>
      IF Experience (in Year) Explain IF not type N/A :
        <input type="text" value={IfExperienceExplain} onChange={(e) => setIfExperienceExplain(e.target.value)} />
      </label>
      {errors.StandingBackLog && <span className="error-message">{errors.StandingBackLog}</span>}
      <label>
      Standing Backlog:
        <input type="text" value={StandingBackLog} onChange={(e) => setStandingBackLog(e.target.value)} />
      </label>
      {errors.FirstCompanyName && <span className="error-message">{errors.FirstCompanyName}</span>}
      <label>
        1st Company Name:
        <input type="text" value={FirstCompanyName} onChange={(e) => setFirstCompanyName(e.target.value)} />
      </label>
      {errors.CTC && <span className="error-message">{errors.CTC}</span>}
      <label>
        CTC:
        <input type="text" value={CTC} onChange={(e) => setCTC(e.target.value)} />
      </label>
      {errors.Duration && <span className="error-message">{errors.Duration}</span>}
      <label>
        Duration:
        <input type="text" value={Duration} onChange={(e) => setDuration(e.target.value)} />
      </label>
      {errors.SecondCompanyName && <span className="error-message">{errors.SecondCompanyName}</span>}
      <label>
       2nd Company Name:
        <input type="text" value={SecondCompanyName} onChange={(e) => setSecondCompanyName(e.target.value)} />
      </label>
      {errors.CTC && <span className="error-message">{errors.CTC}</span>}
      <label>
        CTC:
        <input type="text" value={CTC} onChange={(e) => setCTC(e.target.value)} />
      </label>
      {errors.Duration && <span className="error-message">{errors.Duration}</span>}
      <label>
        Duration:
        <input type="text" value={Duration} onChange={(e) => setDuration(e.target.value)} />
      </label>
      {errors.ThirdCompanyName && <span className="error-message">{errors.ThirdCompanyName}</span>}
      <label>
        3rd Company Name:
        <input type="text" value={ThirdCompanyName} onChange={(e) => setThirdCompanyName(e.target.value)} />
      </label>
      {errors.CTC && <span className="error-message">{errors.CTC}</span>}
      <label>
        CTC:
        <input type="text" value={CTC} onChange={(e) => setCTC(e.target.value)} />
      </label>
      {errors.Duration && <span className="error-message">{errors.Duration}</span>}
      <label>
        Duration:
        <input type="text" value={Duration} onChange={(e) => setDuration(e.target.value)} />
      </label>
     {errors.permanentAddress && <span className="error-message">{errors.permanentAddress}</span>}
      <label>
        Permanent Address:
        <textarea value={permanentAddress} onChange={(e) => setPermanentAddress(e.target.value)} />
      </label>
      {errors.currentAddress && <span className="error-message">{errors.currentAddress}</span>}
      <label>
        Current Address:
        <textarea value={currentAddress} onChange={(e) => setCurrentAddress(e.target.value)} />
      </label>
      {errors.parentContactNumber && <span className="error-message">{errors.parentContactNumber}</span>}
      <label>
        Parent Contact Number:
        <input type="text" value={parentContactNumber} onChange={(e) => setParentContactNumber(e.target.value)} />
      </label>
      <button type="submit">Submit</button>
    </form>
    </div>
    </>
  );
};

export default Experience;
