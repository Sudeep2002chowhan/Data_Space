import React from 'react'
import Header from '../Header';
import "./ContactusStyle.css";
import { Link } from 'react-router-dom'
const Contactus = () => {
  return (
    <div>
    <Header/>

    <section className="page-title" style={{ backgroundColor: "#164564",marginTop:"90px" , padding:"50px"}}>
        <div className="auto-container" style={{marginLeft:"510px"}}>
          <h1 className="d-none d-lg-block d-xl-block d-md-block" style={{color:"white"}}>CONTACT US</h1>
          <ul className="bread-crumb clearfix">
            <li>
              <Link to="/" style={{marginLeft:"50px"}}>Home</Link>
            </li>
  
          </ul>
        </div>
      </section>
      <div className="content bgimg2">
  <div className="mainContent" style={{marginTop:"50px"}} >
    <div className="contactpage">
      <div className="contactpage-left" style={{ width: "44%", border:"solid black 3px",backgroundColor:"white" ,marginTop:"10px" }}>
        <div className="contact-content">
          <div className="">
            <i className="" />
          </div>
          <div className="data">
            <h5>Address</h5>
            {/* <a
              className="contact-link"
              href="https://maps.google.com/?q=2nd Floor, Durga Bhavani Plaza, Satyam Theatre Road, Ameerpet, Hyderabad, Telangana 500016"
              target="_blank"
            > */}
            #12,second Floor,3rd cross,patel narayana Reddy Layout,6th block Koramangala Bangalore-560095
            {/* </a> */}
          </div>
        </div>
        <div className="contact-content">
          <div className="">
            <i className="" />
          </div>
          <div className="data">
            <h5>Email</h5>
            {/* <a className="contact-link" href="mailto: support@nareshit.com">
              support@nareshit.com
            </a> */}
          </div>
        </div>
        <div className="contact-content">
          <div className="">
            <i className="" />
          </div>
          <div className="data">
            <h5>Phone</h5>
            <a className="contact-link" 
            href="tel:+91-9606910681"
            >
              +91-9606910681{" "}
            </a>
          </div>
        </div>
        <div className="social-link">
          {/* <a
            href="//api.whatsapp.com/send?phone=+91-9606910681"
            target="_blank"
          >
            <i className="fa fa-whatsapp" />
          </a> */}
        </div>
      </div>
      <div className="contactpage-right" style={{border:"solid black 3px" }}>
        <h3>Submit Your Query</h3>
        <input
          className="loginInput"
          type="text"
          placeholder="Full Name"
          defaultValue=""
        />
        <input
          className="loginInput"
          placeholder="Mobile Number"
          defaultValue=""
        />
        <input
          className="loginInput"
          placeholder="Email"
          type="email"
          defaultValue=""
        />
        <textarea
          className="loginInput"
          placeholder="Message"
          rows={5}
          style={{ height: 60, padding: 10 }}
          defaultValue={""}
        />
        <button
          className="ok"
          style={{ padding: "6px 20px", marginTop: 10, opacity: 1,color:"black" }}
        >
        Submit
        </button>
      </div>
    </div>
  </div>
</div>

    </div>
  )
}

export default Contactus