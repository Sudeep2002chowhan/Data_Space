import React from 'react'
import { Link } from 'react-router-dom'
import "./FooterStyle.css"

const Footer = () => {
  return (
    <div  style={{ backgroundColor:'#7A858D', border: '7px solid white',margin:"40px",marginTop:"120px",position:'auto',color:"black"}}>
     <footer>
  <div className="main-content" >
    <div className="left box">
      <h2>About us</h2>
      <div className="content">
        <Link to="/">
          <span>Data</span>base.in
        </Link>
        <p     style={{ fontSize: 20, color: "white" }}>
          <b>A Journey With Freshers</b>
          <br />
          We provide free materials which will <br />
          help freshers for their campus preparation.
        </p>
        <div className="social">
          Join for Updates
          <Link to="/" target="_blank">
            <span
              className="fab fa-telegram"
              style={{ fontSize: 20, color: "white" }}
              aria-hidden="true"
            />
          </Link>
        </div>
      </div>
    </div>
    <div className="center box" >
      <h2>Know more</h2>
      <div className="content" >
      <br/>
      <div className="place" >
          <Link to="/">
            <span className="text" style={{ fontSize: 20, color: "white" }} > Home </span>
          </Link>
        </div>
        <br/>
        <div className="place">
          <a href="/About">
            <span className="text" style={{ fontSize: 20, color: "white" }}> About Us </span>
          </a>
        </div>
        <div className="phone">
          <a href="/contactus">
            <span className="text" style={{ fontSize: 20, color: "white" }}> Contact Us</span>
          </a>
        </div>
        <div className="email">
          <a href="/Careers">
            <span className="text" style={{ fontSize: 20, color: "white" }}> Careers</span>
          </a>
        </div>
      </div>
    </div>
    <div className="right box">
      <h2>Address </h2>

      <div className="content">
      
        <div className="place">
       <Link to="/">
            <span className="text" style={{ fontSize: 20, color: "white" }}>#12,Second Floor,3rd cross,Patel Narayana Reddy Layout ,6th Block Koramangala Bangalore-560095</span>
          </Link>
        </div>
        <div className="Contact">
          <Link to="/Contactus">
            <span className="text" style={{ fontSize: 20, color: "white" }}>+91 9606910685</span>
          </Link>
        </div>
        <div className="copy">
    <p style={{ fontSize: 20, color: "white",marginTop:"40px",marginLeft:"-300px" }}>@2023 Database.in All Rights Reserved.</p>
    <p />
    </div>
      </div>
    
      </div>
  <div className="right box">
      <h2>Contribute </h2>
      <div className="content">
        <div className="place">
          <a href="Fresher">
            <span className="text" style={{ fontSize: 20, color: "white" }}>Fresher </span>
          </a>
        </div>
        <div className="phone">
          <a href="Experience">
            <span className="text" style={{ fontSize: 20, color: "white" }}> Experience</span>
          </a>
        </div>
        <div className="email">
          <Link to="mailto:Database.in@gmail.com">
            <span className="text"style={{ fontSize: 20, color: "white" }}> Send any Questions</span>
          </Link>
        </div>
       </div>
      </div>
     </div>
     </footer>
    </div>
  )
}

export default Footer
