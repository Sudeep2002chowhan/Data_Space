import React from 'react'
import Header from '../Header';
import './CareersStyle.css';
import { Link } from 'react-router-dom'
const Careers = () => {
  return (
    <div>
    <Header/>
    {/* <section className="heading-page" style={{marginTop:"85px"}}>

  {" "}

  <img src="https://ms-cloud.com/images/aboutus-bnr.jpg" alt="" />

  <div className="container">

    <div className="heading-page-content">

      <div className="au-page-title">

        <h1>career</h1>

      </div>

      <nav aria-label="breadcrumb">

        <ul className="breadcrumb">

          <li className="breadcrumb-item">

            <a href="index.html">Home</a>

          </li>

          <li className="breadcrumb-item active" aria-current="page">

            About

          </li>

        </ul>

      </nav>

    </div>

  </div>

</section> */}
<section className="page-title" style={{ backgroundColor: "#208ED4",marginTop:"90px" , padding:"50px"}}>
        <div className="auto-container" style={{marginLeft:"510px"}}>
          <h1 className="d-none d-lg-block d-xl-block d-md-block" style={{color:"white"}}>CAREER'S</h1>
          <ul className="bread-crumb clearfix">
            <li>
              <Link to="/" style={{marginLeft:"50px"}}>Home</Link>
            </li>
  
          </ul>
        </div>
      </section>
      <section
  className="aboutus-skillls section-padding-large js-waypoint wow fadeIn"
  data-wow-delay="0.3s"
  style={{
    visibility: "visible",
    animationDelay: "0.3s",
    animationName: "fadeIn"
    
  }}
>
  <div className="container" >
    <div className="our-skillls-content">
      <div className="row">
        <div className="col-xl-6 col-lg-6 col-md-4 col-sm-12 col-12" >
          <div className="list-skills">
            <h2 className="title"> Careers</h2>
            <h3> Benefits of working with Marella Softlabs Private Limited</h3>
            <p className="desc">
              Fast professional growth, social package, high salary, flexible
              working schedule. Today LEAD is backed by a team of enthusiastic
              and forward-thinking managers, IT analysts, business analysts,
              software architects, programmers, developers, testers, QA
              engineers, maintenance staff, etc. All these people are diverse,
              but they have one thing in common – their talent and persistent
              desire for self-improvement as well as their willingness to
              contribute to the company success. We understand that what is
              advantageous for our clients is also beneficial for LEAD and is
              eventually good for its employees.
            </p>
          </div>
        </div>
        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-8">
          <div className="skills">
            <p>
              <img src="https://ms-cloud.com/images/career.jpg" alt="" />
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



    </div>
  )
}

export default Careers
