import React from 'react'
import { Link } from 'react-router-dom';
import "./HomeimgStyle.css";

const HomeImg = () => {
  return (
    <div>
    <div id="banner" className="home-banner">
  <img style={{marginTop:"92px",height:"500px"}}
    // src="https://mcdn.wallpapersafari.com/medium/73/54/TDFtVp.jpg"
    // src="https://mcdn.wallpapersafari.com/medium/32/30/gIB8ws.jpg"
    // src="https://mcdn.wallpapersafari.com/medium/28/71/HATjy8.jpg"
    // src="https://mcdn.wallpapersafari.com/medium/77/71/Ti6Vko.jpg"
    src="https://wallpapers.com/images/hd/database-info-exchange-03ghlfed30kkhvnj.jpg"
  
    alt="Database"
    className="home-banner-img"
    id=""
    height=""
    width=""
    data-testid="guesthomepage_homebanner"
    
  />
  <div className='op'>
    
  </div>
  <div
    className="home-banner-copy"
    data-testid="guesthomepage_homebanner_title"
  >
   <div className="btn-box">
                  <Link style={{backgroundColor:"#0608D1"}} to="/Fresher" className="theme-btn btn btn-style-one">
                    <span className="btn-title" style={{color:"white"}}>Fresher</span>
                  </Link>
                </div>
                <br/>
                <div className="btn-box">
                  <Link  style={{backgroundColor:"#0608D1"}} to="/Experience" className="theme-btn btn btn-style-one">
                    <span className="btn-title" style={{color:"white"}}>Experience</span>
                  </Link>
                </div>
    {/* <h1>EXPERT INSTRUCTION</h1> */}
{/* Convenient easy way of learning new skills! */}
  </div>
</div>


    </div>
  )
}

export default HomeImg