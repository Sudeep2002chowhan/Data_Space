import React from 'react'
import { Link } from 'react-router-dom'
import './HeaderStyle.css';
const Header = () => {
  return (
    <div>
          <div>
      <header className="main-header header-style-two">
       
        <div className="main-box"style={{backgroundColor:"#20425A"}}>
          <div className="auto-container clearfix" >
            <div className="logo-box">
              <div className="logo">
                {/* <Link to="/">
                  <img
                    style={{ borderRadius: "20px" }}
                    src="https://cdn.cdnparenting.com/articles/2021/09/14191221/08938f86cbffaa4d3027c4c45067a2a8.webp"
                    alt=""
                    title=""
                    height={150}
                    width={70}
                  />
                </Link> */}
              </div>
            </div>
            {/*Nav Box*/}
            <div className="nav-outer clearfix">
              <div className="mobileapp_Icon1">
                <Link to="" target="_blank">
                  <img src="https://www.matrimonysoftware.in/images/app-ic.png" />
                </Link>
              </div>

              <div className="mobile-nav-toggler">
                <span className="icon flaticon-menu" />
              </div>
              {/* Main Menu */}
              <nav className="main-menu navbar-expand-md navbar-light">
                <div className="navbar-header">
                  {/* Togg le Button */}
                  <button
                    className="navbar-toggler"
                    type="button"
                    data-toggle="collapse"
                    data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                  >
                    <span className="icon flaticon-menu-button" />
                  </button>
                </div>
                <div
                  className="collapse navbar-collapse clearfix"
                  id="navbarSupportedContent"
                >
                  <ul className="navigation clearfix">
                    <li className="current dropdown">
                      <Link to="/" style={{ color: "white" }}>
                        Home
                      </Link>
                      <div className="dropdown-btn">
                        <span className="fa fa-angle-down" />
                      </div>
                    </li>
                    <li className="dropdown">
                      <Link to="/About" style={{ color: "white" }}>
                        About Us
                      </Link>
                      {/* <ul>
                        <li>
                          <Link to="/About">About Us</Link>
                        </li>
                        <li>
                          <Link to="/terms-conditions">
                            Terms &amp; Condation
                          </Link>
                        </li>
                        <li>
                          <Link to="/faqs">FAQ's</Link>
                        </li>
                        <li>
                          <Link to="/privacy-policy">Privacy Policy</Link>
                        </li>
                        <li>
                          <Link to="/returns-and-cancellation">
                            Refund Policy
                          </Link>
                        </li>
                        <li>
                          <Link to="/disclaimer">Disclaimer</Link>
                        </li>
                        <li>
                          <Link to="/safematrimony">Safe Matrimony</Link>
                        </li>
                      </ul> */}
                      <div className="dropdown-btn">
                        <span className="fa fa-angle-down" />
                      </div>
                    </li>

                    <li>
                <Link to="/Careers" style={{ color: "white" }}>Careers</Link>
              </li>
                   
                    <li>
                      <Link to="/Contactus" style={{ color: "white" }}>
                        Contact
                      </Link>
                    </li>
                    <li className="dropdown">
                      <Link to="/" style={{ color: "white" }}>
                        Application from
                      </Link>
                      <ul>
                        <li>
                          <Link to="/Fresher">Fresher</Link>
                        </li>
                        <li>
                          <Link to="/Experience">
                           Experience
                          </Link>
                        </li>
                        </ul>
                    </li>
                  </ul>
                </div>
              </nav>
              {/* Main Menu End*/}
              {/* Outer box */}
              <div className="outer-box">
                {/*Search Box*/}
                {/* <div className="search-box-btn">
            <span className="flaticon-search" />
          </div> */}
                {/* Button Box */}
                <div className="btn-box">
                  <Link style={{backgroundColor:"white" , color:"blue"}} to="/Login" className="theme-btn btn btn-style-one">
                    <span className="btn-title" >Login</span>
                  </Link>
                </div>
                <div className="btn-box">
                  <Link  style={{backgroundColor:"white" , color:"blue"}} to="/Signup" className="theme-btn btn btn-style-one">
                    <span className="btn-title" >SignUp</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Mobile Menu  */}
        
        {/* End Mobile Menu */}
      </header>
    </div>
    </div>
  )
}

export default Header
