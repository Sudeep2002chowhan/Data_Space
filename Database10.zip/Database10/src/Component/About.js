import React from 'react'
import "./AboutStyle.css"
import Header from './Header'
import { Link } from 'react-router-dom'

const About = () => {
  return (
    <div>
        <Header/>

        {/* <section className="page-title" style={{ backgroundColor: "black",marginTop:"93px"}}>
        <div className="auto-container">
          <h1 className="d-none d-lg-block d-xl-block d-md-block">About Us</h1>
          <ul className="bread-crumb clearfix">
            <li>
              <a href="/">Home</a>
            </li>
            <li>About Us</li>
          </ul>
        </div>
      </section> */}

{/* <section className="heading-page" style={{marginTop:"70px"}}>
  {" "}
  <img src="https://ms-cloud.com/images/aboutus-bnr.jpg" alt="" />
  <div className="container">
    <div className="heading-page-content">
      <div className="au-page-title">
        <h1>About us</h1>
      </div>
      <nav aria-label="breadcrumb">
        <ul className="breadcrumb">
          <li className="breadcrumb-item">
            <a href="index.html">Home</a>
          </li>
          <li className="breadcrumb-item active" aria-current="page">
            About
          </li>
        </ul>
      </nav>
    </div>
  </div>
</section> */}

<section className="page-title" style={{ backgroundColor:"Black",marginTop:"90px" , padding:"50px"}}>
        <div className="auto-container" style={{marginLeft:"510px"}}>
          <h1 className="d-none d-lg-block d-xl-block d-md-block" style={{color:"white"}}>ABOUT US</h1>
          <ul className="bread-crumb clearfix">
            <li>
              <Link to="/" style={{marginLeft:"50px"}}>Home</Link>
            </li>
  
          </ul>
        </div>
      </section>

  <section className="about-section"></section>


      <section
  className="aboutus-skillls section-padding-large js-waypoint wow fadeIn"
  data-wow-delay="0.3s"
  style={{
    visibility: "visible",
    animationDelay: "0.3s",
    animationName: "fadeIn"
  }}
>
  <div className="container">
    <div className="our-skillls-content">
      <div className="row">
        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
          <div className="list-skills">
            <h2 className="title"> Marella Softlabs Private Limited</h2>
            <h3>
              we are helping our clients to achieve their business focuses by
              successfully redistributing their non-focus business handle and
              passing on embraced plans.
            </h3>
            <p className="desc">
              Marella Softlabs the best talent in the company, we offer you
              genuine affordable services with unconditional customer-centric
              approach. Our services range from Software Development and Website
              Designing to Web hosting services including E-Marketing services.
              Apart from this, we have the honor of being the foremost company
              to begin website hosting in India.
            </p>
            <p className="desc">
              Our Software Development Team is a unique fusion of experience and
              skills that will help you achieve the optimum profitability your
              business needs without compromising in quality.{" "}
            </p>
          </div>
        </div>
        <div className="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
          <div className="skills">
            <p>
              <img src="https://ms-cloud.com/images/categories-1.jpg" alt=""/>
            </p>
          </div>
        </div>
        <div className="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
          <div className="list-skills">
            <p className="desc">
              Though our core expertise lies in Application designing and
              development, software development, Data Analytics, Cloud Services,
              mass mailing and web hosting but we are also independent vendors
              of various ready-to-use Software Products.
            </p>
            <p className="desc">
              We, at Marella Softlabs, understand that just as beauty is in the
              eye of the beholder; it is you the customer who perceives the
              quality of the product. Hence, here at Marella Softlabs you are
              the real builder, we just help you realise your vision. Contact us
              now to receive a free website development proposal or a free
              consultation with our agent.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


    </div>
  )
}

export default About
