import React from 'react'
import "./ValuesStyle.css";
const Values = () => {
  return (
    <div style={{ marginTop:"-60px"}}>
    <div className='frform' style={{ backgroundColor:'lightblue', border: '7px solid white ',margin:"40px",marginTop:"120px",position:'auto'}}>

    <div >
      <div className="c-placeholders" >
  {" "}
  <div className="container" >
    {" "}
    <div className="row">
      {" "}
      <div id="desktop">
        {" "}
        <div className="col-md-12 text-center" style={{ marginBottom: 20 }}>
          {" "}
          <h3 style={{color:"black"}}>
            Our Core <span>Values</span>
          </h3>{" "}
        </div>{" "}
        <div className="col-md-2 text-center" style={{ marginLeft: 62 }}>
          {" "}
          <p className="c-princple-list">Customer Success</p>{" "}
        </div>{" "}
        <div className="col-md-2 text-center">
          {" "}
          <p className="c-princple-list" style={{ marginLeft: 30 }}>
            Integrity
          </p>{" "}
        </div>{" "}
        <div className="col-md-2 text-center">
          {" "}
          <p className="c-princple-list" style={{ marginLeft: 60 }}>
            Respect
          </p>{" "}
        </div>{" "}
        <div className="col-md-2 text-center">
          {" "}
          <p className="c-princple-list" style={{ marginLeft: 95 }}>
            Innovation
          </p>{" "}
        </div>{" "}
        <div className="col-md-2 text-center">
          {" "}
          <p className="c-princple-list" style={{ marginLeft: 115 }}>
            Learning
          </p>{" "}
        </div>{" "}
        <div className="col-md-12 text-center">
          {" "}
          <img
            src="https://datamites.com/resource/images//career/career-info-graphics.png"
            alt=""
            className=" infographic-1"
          />{" "}
          {/* <div class="c-princple"> <p class="c-princple-list">Customer Success</p> <p class="c-princple-list" style= "margin-left: -17px;">intergity</p> <p class="c-princple-list">Respect</p> <p class="c-princple-list">Innovation</p> <p class="c-princple-list">Learning</p> </div> */}{" "}
        </div>{" "}
        <div className="col-md-12" style={{ display: "contents" }}>
          {" "}
          <p className="c-princple-list2" style={{ width: "20%" }}>
            We focus on achieving our customer’s goals. We believe that
            everything else will follow.
          </p>{" "}
          <p className="c-princple-list2" style={{ width: "20%" }}>
            We act with uncompromising honesty and integrity in everything we
            do. We strive hard to enable transparency to all stakeholders
            including our customers and colleagues, in every aspect of the
            business.
          </p>{" "}
          <p className="c-princple-list2" style={{ width: "20%" }}>
            We respect and care for our social and physical environment around
            the world. We treat everyone, our colleagues, customers and all
            other stakeholders with dignity and professionalism.
          </p>{" "}
          <p className="c-princple-list2" style={{ width: "20%" }}>
            We constantly strive to be innovative, encouraging new ideas,
            experimenting new approaches with new technologies. We believe that
            innovation is at the heart of our continued success.
          </p>{" "}
          <p className="c-princple-list2" style={{ width: "20%" }}>
            We believe in a culture of humility and continuous learning is the
            way to be successful in this fast changing world.
          </p>{" "}
        </div>{" "}
      </div>{" "}
      <div id="mobile">
        {" "}
        <div className="col-md-12 text-center" style={{ marginBottom: 20 }}>
          {" "}
          <h3>
            Our Core <span>Values</span>
          </h3>{" "}
        </div>{" "}
        <div className="col-md-12 text-center">
          {" "}
          <img
            src="https://datamites.com/resource/images//career/career-info-graphics.png"
            alt=""
            className=" infographic-1"
          />{" "}
        </div>{" "}
        <div className="col-md-12">
          {" "}
          <p className="c-princple-list3">
            <span style={{ fontSize: 18, color: "#000" }}>
              Customer Success
            </span>
            <br />
            We focus on achieving our customer’s goals. We believe that
            everything else will follow.
            <br />
          </p>{" "}
          <p className="c-princple-list3">
            <span style={{ fontSize: 18, color: "#000" }}>Integrity</span>
            <br />
            We act with uncompromising honesty and integrity in everything we
            do. We strive hard to enable transparency to all stakeholders
            including our customers and colleagues, in every aspect of the
            business.
            <br />
          </p>{" "}
          <p className="c-princple-list3">
            <span style={{ fontSize: 18, color: "#000" }}>Respect</span>
            <br />
            We respect and care for our social and physical environment around
            the world. We treat everyone, our colleagues, customers and all
            other stakeholders with dignity and professionalism.
            <br />
          </p>{" "}
          <p className="c-princple-list3">
            <span style={{ fontSize: 18, color: "#000" }}>Innovation</span>
            <br />
            We constantly strive to be innovative, encouraging new ideas,
            experimenting new approaches with new technologies. We believe that
            innovation is at the heart of our continued success.
            <br />
          </p>{" "}
          <p className="c-princple-list3">
            <span style={{ fontSize: 18, color: "#000" }}>learning</span>
            <br />
            We believe in a culture of humility and continuous learning is the
            way to be successful in this fast changing world.
            <br />
          </p>{" "}
        </div>{" "}
      </div>{" "}
    </div>{" "}
  </div>{" "}
</div>
    </div>
    </div>
    </div>
  )
}

export default Values
